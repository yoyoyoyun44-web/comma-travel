// 쉼표여행 무료 관광정보 연결용 Cloudflare Worker
// Cloudflare Dashboard > Workers & Pages > Create Worker 에 붙여넣으세요.
// 이후 Settings > Variables and Secrets 에 TOUR_API_KEY 를 Secret 으로 등록하세요.
// TOUR_API_KEY 값에는 공공데이터포털의 일반 인증키(Decoding)를 넣습니다.
// 인증키를 앱 HTML 안에 직접 넣지 마세요.

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "public, max-age=300"
};

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    if (request.method !== "GET") {
      return json({ ok: false, message: "GET 요청만 지원합니다." }, 405);
    }

    if (!env.TOUR_API_KEY) {
      return json({
        ok: false,
        message: "서버에 TOUR_API_KEY Secret이 설정되지 않았습니다."
      }, 500);
    }

    const keyword = (url.searchParams.get("keyword") || "").trim();
    if (keyword.length < 2) {
      return json({ ok: false, message: "검색어를 두 글자 이상 입력해 주세요." }, 400);
    }
    if (keyword.length > 50) {
      return json({ ok: false, message: "검색어는 50자 이내로 입력해 주세요." }, 400);
    }

    const apiUrl = new URL("https://apis.data.go.kr/B551011/KorService2/searchKeyword2");
    apiUrl.search = new URLSearchParams({
      serviceKey: env.TOUR_API_KEY,
      numOfRows: "20",
      pageNo: "1",
      MobileOS: "ETC",
      MobileApp: "CommaTrip",
      _type: "json",
      listYN: "Y",
      arrange: "A",
      keyword
    }).toString();

    try {
      const upstream = await fetch(apiUrl.toString(), {
        headers: { "Accept": "application/json" }
      });
      const bodyText = await upstream.text();

      if (!upstream.ok) {
        return json({
          ok: false,
          message: "한국관광공사 API 응답 오류",
          upstreamStatus: upstream.status
        }, 502);
      }

      let data;
      try {
        data = JSON.parse(bodyText);
      } catch {
        return json({
          ok: false,
          message: "API 응답을 JSON으로 해석하지 못했습니다. 인증키와 활용신청 상태를 확인해 주세요."
        }, 502);
      }

      const header = data?.response?.header;
      const resultCode = header?.resultCode;
      if (resultCode && resultCode !== "0000") {
        return json({
          ok: false,
          message: "한국관광공사 API가 오류를 반환했습니다.",
          resultCode,
          resultMsg: header?.resultMsg || "오류 메시지가 없습니다."
        }, 502);
      }

      const rawItems = data?.response?.body?.items?.item;
      const items = rawItems ? (Array.isArray(rawItems) ? rawItems : [rawItems]) : [];

      return json({
        ok: true,
        keyword,
        count: items.length,
        items: items.map(item => ({
          title: stripHtml(item.title || ""),
          address: item.addr1 || "",
          addressDetail: item.addr2 || "",
          category: item.cat2 || item.cat1 || "",
          contentTypeId: item.contenttypeid || "",
          contentId: item.contentid || "",
          image: item.firstimage || item.firstimage2 || "",
          mapX: item.mapx || "",
          mapY: item.mapy || "",
          tel: item.tel || "",
          source: "한국관광공사 국문 관광정보 서비스"
        }))
      });
    } catch (error) {
      return json({
        ok: false,
        message: "관광정보 API에 연결하지 못했습니다. 잠시 후 다시 시도해 주세요."
      }, 502);
    }
  }
};

function stripHtml(value) {
  return String(value).replace(/<[^>]*>/g, "").trim();
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: corsHeaders });
}
