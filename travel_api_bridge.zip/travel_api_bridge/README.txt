# 쉼표여행 무료 관광정보 연결 브리지

이 파일은 한국관광공사 국문 관광정보 API를 쉼표여행 앱에 연결하기 위한 Cloudflare Worker 예시입니다.

## 1. Worker 만들기
1. Cloudflare에 로그인한 뒤 Workers & Pages로 이동합니다.
2. Create application 또는 Create Worker를 선택합니다.
3. 새 Worker를 만들고 `worker.js` 내용을 편집기에 붙여넣어 저장/배포합니다.
4. Worker 주소를 복사해 둡니다. 예: `https://comma-trip-api.<계정>.workers.dev`

## 2. 인증키를 Secret으로 등록
1. Worker 설정의 Variables and Secrets 메뉴로 이동합니다.
2. Secret 변수를 추가합니다.
3. 이름: `TOUR_API_KEY`
4. 값: 공공데이터포털에서 발급받은 일반 인증키(Decoding)
5. 저장 후 재배포가 필요하면 재배포합니다.

인증키를 HTML/JavaScript에 직접 붙여넣거나 공개 채팅에 보내지 마세요.

## 3. 연결 테스트
브라우저에서 다음 주소를 엽니다. `WORKER_URL`을 본인의 Worker 주소로 바꾸세요.

`WORKER_URL/?keyword=제주`

성공하면 `ok: true`와 관광지 `items` 목록이 JSON으로 나옵니다.
`ok: false`가 나오면 표시된 메시지를 확인하세요.

## 무료 이용 관련
- 한국관광공사 API 개발계정은 신청 페이지에 표시된 이용량 한도를 준수해야 합니다.
- Cloudflare 무료 플랜의 한도와 정책은 계정 화면에서 확인하세요.
- 이 Worker는 검색어 길이 제한을 두었지만, 공개 배포 시에는 필요에 따라 허용 도메인 제한과 추가 호출 제한을 설정하세요.
- 앱 공개 전 실제 운영 환경에서 키 보안과 이용약관을 다시 확인하세요.
